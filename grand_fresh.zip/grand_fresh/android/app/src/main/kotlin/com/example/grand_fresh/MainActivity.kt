package com.example.grand_fresh

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
